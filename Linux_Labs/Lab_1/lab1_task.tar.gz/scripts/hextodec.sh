#!/usr/bin/env bash
printf "%d\n " "$1"
