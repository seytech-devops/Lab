#!/usr/bin/env bash

wc -l ./*
